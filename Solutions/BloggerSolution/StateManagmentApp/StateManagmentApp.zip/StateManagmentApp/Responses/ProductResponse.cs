﻿namespace StateManagmentApp.Responses
{
    public class ProductResponse
    {
    }
}
